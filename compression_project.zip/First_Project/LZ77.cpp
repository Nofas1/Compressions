#include "LZ77.h"

LZ77::LZ77() {}

void LZ77::compress() 
{
    int l_buffer = preCheck().first, r_buffer = preCheck().second;
    afterSolve(l_buffer, r_buffer);
    // fullCompress();
    
}

my_types::pii LZ77::preCheck()
{
    int l_buffer = 0, r_buffer = 0;
    int size = std::min(my_types::size_of_window, static_cast<int>(data.size()));
    int pos = 0;

    while (pos < size) {
        int offset = 0;
        int length = 1;
        shiftBuffer(l_buffer, r_buffer, length);
        pos += length;
        used.push_back({offset, length, data[pos]});
    }
    return {l_buffer, r_buffer};
}

void LZ77::afterSolve(int l_buffer, int r_buffer)
{
    int pos = used.size() - 1;
    while (pos < data.size()) {
        my_types::pii curr = findMatching(pos);
        int offset = curr.first;
        int length = curr.second;
        shiftBuffer(l_buffer, r_buffer, length + 1);
        pos += length;
        used.push_back({offset, length, data[pos]});
    }
}

// void LZ77::fullCompress()
// {
//     int l_buffer = 0, r_buffer = 0;
//     int size = std::min(my_types::size_of_window, static_cast<int>(data.size()));
//     int pos = 0;

//     while (pos < data.size()) {
//         my_types::pii curr = findMatching(pos);
//         int offset = curr.first;
//         int length = curr.second;
//         shiftBuffer(l_buffer, r_buffer, length + 1);
//         pos += length;
//         used.push_back({offset, length, data[pos]});
//     }
// }

my_types::pii LZ77::findMatching(int pos)
{
    if (pos >= data.size()) {
        return {0, 0};
    }
    int bestMatchLength = 0;
    int bestMatchOffset = 0;

    for (int i = std::max(0, pos - my_types::BUFFER_SIZE); i < pos; ++i) {
        int matchLength = 0;

        while (matchLength + pos < data.size() and data[i + matchLength] == data[pos + matchLength]) {
            ++matchLength;
            if (matchLength == my_types::BUFFER_SIZE) {
                break;
            }
        }
        if (bestMatchLength < matchLength) {
            bestMatchLength = matchLength;
            bestMatchOffset = pos - i;
        }
    }
    return {bestMatchOffset, bestMatchLength};
}

void LZ77::shiftBuffer(int l, int r, int x)
{
    if (r + x <= data.size()) {
        if (r - l < my_types::BUFFER_SIZE) {
            r += x;
        } else {
            l += x;
            r += x;
        }
    }
}


void LZ77::decompress()
{
    std::string file_info = "";
    std::getline(data_file, file_info);
    std::string new_data = "";

    std::vector<LZ77::Node> new_node = reformat();
    
    for (Node& node : new_used) {
        if (node.length) {
            int first = node.length - node.offset;
            for (int i = 0; i <= node.length - 1; ++i) {
                new_data += data[first + i];
            }
        }
        new_data += node.next;
    }
}

std::vector<LZ77::Node> LZ77::reformat()
{
    std::string file_info = "";
    std::getline(data_file, file_info);
    std::vector<LZ77::Node> new_node;

    

    return new_node;
}
