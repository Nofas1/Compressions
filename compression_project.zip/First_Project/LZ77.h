#pragma once

#include "My_types.h"
#include "Compressor.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

#define all(a) (a).begin(), (a).end()


class LZ77 : public Compressor
{
    struct Node {
        int offset; // offset back from current position
        int length; // length of matching substring
        char next; // next char
    };
    
    std::vector<Node> used;

    std::ifstream data_file;
    std::ofstream result_file;
    std::vector<Node> new_used;

public:
    LZ77();

    void compress();

    // adding chars till the buffer won't become it's true size
    my_types::pii preCheck();

    void afterSolve(int, int);

    // finding the same subsequence of chars
    my_types::pii findMatching(int);

    // moves our buffer forward on "a" points
    void shiftBuffer(int, int, int);

    // return back to the real data, receiving <string>
    void decompress();

    // переписывать в new_used данные из файла data_file, чтобы потом можно было засунуть в result_file
    std::vector<Node> reformat();
};


#undef all(a)
