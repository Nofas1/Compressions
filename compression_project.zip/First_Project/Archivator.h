#pragma once

#include "My_types.h"
#include "Builder.h"

#include <iostream>
#include <fstream>


// only data work

class Archivator
{
    // pointer to object: how to compress
    Builder* build;
    // pointer to object: where info on current compression is
    Compressor* compression;

public:

    Archivator(my_types::ChooseYourCompression);

    ~Archivator();

    // taking type of compression from Builder, than loading this into Class Compressor, so we will know what to compress
    void send_buffer(std::string&);

    void save();

    // user gives us a way to file, which we should fullfill with data
    void user_compress(const std::string&);

    // also gives us string way to file, consists of our data, which we should convert into vector<Node>
    void user_decompress(const std::string&, const std::string&);
};

