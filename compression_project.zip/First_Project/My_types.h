#pragma once

#include <utility>

namespace my_types{
    const int BUFFER_SIZE = 16;
    const int size_of_window = 512;
    typedef long long ll;
    typedef long double ld;
    typedef std::pair<int, int> pii;
    typedef std::pair<ll, ll> pll;
    typedef std::pair<int, char> pic;

    // range of compressions that user choose
    enum ChooseYourCompression
    {
        LZ77 = 1,
        LZMA,
        Deflate
    };

    // type of action that user choose
    enum CompressOrDecompress
    {
        compress = 1,
        decompress
    };
}


