#include "Deflate.h"

LZ77::LZ77() {}

void LZ77::compress() 
{
    preCheck();
}

void LZ77::preCheck()
{
    int l_buffer = 0, r_buffer = 0;
    int size = std::min(my_types::size_of_window, static_cast<int>(data.size()));
    int pos = 0;

    while (pos < data.size()) {
        my_types::pii curr = findMatching(pos);
        int offset = curr.first;
        int length = curr.second;
        shiftBuffer(l_buffer, r_buffer, length + 1);
        pos += length;
        used.push_back({offset, length, data[pos]});
    }
}

my_types::pii LZ77::findMatching(int pos)
{
    if (pos >= data.size()) {
        return {0, 0};
    }
    int bestMatchLength = 0;
    int bestMatchOffset = 0;

    for (int i = std::max(0, pos - my_types::BUFFER_SIZE); i < pos; ++i) {
        int matchLength = 0;

        while (matchLength + pos < data.size() and data[i + matchLength] == data[pos + matchLength]) {
            ++matchLength;
            if (matchLength == my_types::BUFFER_SIZE) {
                break;
            }
        }
        if (bestMatchLength < matchLength) {
            bestMatchLength = matchLength;
            bestMatchOffset = pos - i;
        }
    }
    return {bestMatchOffset, bestMatchLength};
}

void LZ77::shiftBuffer(int l, int r, int x)
{
    if (r + x <= data.size()) {
        if (r - l < my_types::BUFFER_SIZE) {
            r += x;
        } else {
            l += x;
            r += x;
        }
    }
}

// вспомогательная функция для построения
void Deflate::helper(std::vector<HuffmanNode*>& t, int cnt)
{
    for (int i = cnt; i < t.size() - 1; ++i) {
        HuffmanNode* new_node = new HuffmanNode{{t[i]->val.first + t[i + 1]->val.first, 'Z'}, t[i], t[i + 1]};
        t[i + 1] = new_node;
        sort((t).begin() + i, (t).end(), [](HuffmanNode* a, HuffmanNode* b) {
            return a->val.first < b->val.first;
        });
    }
}

// считывание частоты символов в строчке
int Deflate::get_stats(std::vector<HuffmanNode*>& freq)
{
    for (LZ77::Node& node : used) {
        ++freq[static_cast<int> (el)]->val.first;
    }

    sort((freq).begin(), (freq).end(), [](HuffmanNode* a, HuffmanNode* b) {
            return a->val.first < b->val.first;
    });
    int i = 0, cnt = 0;
    while (!freq[i]) {
        ++cnt;
        ++i;
    }
    return cnt;
}

Deflate::Deflate() : root(nullptr), ans(256) {}

void Deflate::compress()
{
    build();

}


// строим дерево
Deflate::HuffmanNode* Deflate::build()
{
    std::vector<HuffmanNode*> freq(256);
    unsigned char symbol = 0;

    for (HuffmanNode*& el : freq) {
        el = new HuffmanNode{{0, symbol}, nullptr, nullptr};
        ++symbol;
    }
    int cnt = get_stats(freq);
    helper(freq, cnt);
}

// обход дерева(информация только в листьях)
void Deflate::traversal(HuffmanNode* r, int s, int length)
{
    if (!(r->left and r->right)) {
        ans[static_cast<int> (r->val.second)] = {s, length};
    }
    traversal(r->left, s << 1, length++);
    traversal(r->right, (s << 1) ^ 1, length++);
}

// замена и добавление в одну строку
void shift()
{
    std::string s;
    char a = 0;
    int sm = 0;
    for (const char& el : data) {
        int num = ans[static_cast<int> (el)].first;
        int length = ans[static_cast<int> (el)].second;
        int cur_length = sm + length - 8;
        if (cur_length >= 0) {
            int k = num >> cur_length;
            a << (8 - sm) ^ k;
            s += a;
            a = (k << cur_length) ^ num;
            sm = cur_length;
        } else {
            a << length ^ num;
            sm += length;
        }
    }
    if (a) {
        a << (8 - sm);
        s += a;
    }
}

void Deflate::decompress()
{}
