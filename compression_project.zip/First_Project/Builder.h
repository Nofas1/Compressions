#pragma once

#include "My_types.h"
#include "Compressor.h"

#include "LZ77.h"
#include "LZMA.h"
#include "Deflate.h"

class Builder
{
    Compressor* compression;

public:
    // choosing type of compression
    Builder(my_types::ChooseYourCompression option)
    {
        if (option == my_types::LZ77) {
            compression = new LZ77;
        }
        else if (option == my_types::LZMA) {
            compression = new LZMA;
        }
        else {
            compression = new Deflate;
        }
    }

    ~Builder()
    {
        delete compression;
    }

    // giving this info to Archivator
    Compressor* get();
    
};

// куда пихать decompression