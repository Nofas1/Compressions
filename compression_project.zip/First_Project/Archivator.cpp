#include "Archivator.h"
#include "Compressor.h"
#include <fstream>

// прием данных, считывание


Archivator::Archivator(my_types::ChooseYourCompression option) : build(new Builder(option)) {}

Archivator::~Archivator()
{
    delete build;
}

void Archivator::send_buffer(std::string& buffer)
{
    compression = build->get();
    compression->load(buffer);
}

void Archivator::user_compress(const std::string& output_name)
{
    compression->compress();
}

void Archivator::user_decompress(const std::string& input_name, const std::string& output_name)
{
    compression->decompress();
}