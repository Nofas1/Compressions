#pragma once

#include "My_types.h"
#include "Compressor.h"
#include "LZ77.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>


class Deflate : public Compressor
{
    struct HuffmanNode {
        pic val;
        HuffmanNode* left;
        HuffmanNode* right;
    };
    HuffmanNode* root;
    std::vector<pii> ans;

    void helper(std::vector<HuffmanNode*>&, int);

    int get_stats(std::vector<HuffmanNode*>&);

public:
    Deflate();

    void compress();

    HuffmanNode* build();

    void traversal(HuffmanNode*, int, int);
    
    void shift();

    void decompress();
};
