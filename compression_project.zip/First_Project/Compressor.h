#pragma once

#include "My_types.h"

// abstract Class (virtual ... = 0  can't be realised)
class Compressor
{
protected:
    std::string data;

public:
    virtual void compress() = 0;

    virtual void load(std::string& buffer)
    {
        data = buffer;
    }

    virtual void decompress() = 0;
};
