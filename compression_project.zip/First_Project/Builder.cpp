#include "Builder.h"
#include "Archivator.h"

Compressor* Builder::get()
{
    return compression;
}