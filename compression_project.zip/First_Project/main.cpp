#include "My_types.h"
#include "Builder.h"
#include "Archivator.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>

#define all(a) (a).begin(), (a).end()


int main()
{
    // receiving type of compression
    int option;
    std::cin >> option;
    
    // building an object to compress
    Archivator arch(static_cast<my_types::ChooseYourCompression> (option));

    // reading from file and sending it to Archivator
    std::string data;
    std::ifstream file("data.txt");
    std::string buffer;

    while (std::getline(file, data)) {
        buffer += data;
    }

    arch.send_buffer(buffer);
}